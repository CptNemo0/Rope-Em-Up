#ifndef SOUNDS_H
#define SOUNDS_H

namespace audio
{

enum Sounds
{
    bruh
};

}

#endif // SOUNDS_H