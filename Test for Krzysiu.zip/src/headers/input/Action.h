#ifndef ACTION_H
#define ACTION_H

enum Action
{
    // Axis Actions
    MOVE,
    // Button Actions
    PULL_ROPE
};

#endif // !ACTION_H