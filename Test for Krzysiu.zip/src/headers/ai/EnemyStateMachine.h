#ifndef ENEMY_STATE_MACHINE_H
#define ENEMY_STATE_MACHINE_H

#include "../physics/PBD.h"
#include <cassert>
#include "../GameObject.h"
#include "../Vehicle.h"
#include <memory>

namespace ai
{
	class EnemyState;

	
}

#endif // !ENEMY_STATE_MACHINE_H
