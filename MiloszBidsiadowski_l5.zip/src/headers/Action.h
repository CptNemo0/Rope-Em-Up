#ifndef ACTION_H
#define ACTION_H

enum Action
{
    PLAYER_MOVE,
    PULL_ROPE
};

#endif // !ACTION_H